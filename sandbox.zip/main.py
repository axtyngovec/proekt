
from flask import Flask, render_template
import random
import datetime


app = Flask(__name__)


@app.route("/")
def hello_world():
    return render_template('home_page.html')


@app.route("/random")
def random_fun():
    random_num = random.randint(0, 100)
    return render_template('random_page.html', my_random=random_num)


@app.route('/date')
def date_show():
    current_date = datetime.datetime.now()
    return render_template('date_page.html', date=current_date)


@app.route('/people')
def people_show():
    fw = open('units.txt', 'r', encoding='utf-8')
    people_list = fw.read().split('\n')
    return render_template('people_page.html', lines=people_list)


@app.route("/test")
def test_show():
    return render_template('test_page.html')


@app.route("/test2")
def test2_show():
    return render_template('test2_page.html')


@app.route("/test3")
def test3_show():
    return render_template('test3_page.html')


@app.route("/test4")
def test4_show():
    return render_template("test4_page.html", css_file="test4_page.css", js_file="test4_page.script.js")


@app.route("/test5")
def test5_show():
    return render_template("test5_page.html")


@app.route("/test6")
def test6_show():
    return render_template("test6_page.html")


if __name__ == "__main__":
    app.run()
